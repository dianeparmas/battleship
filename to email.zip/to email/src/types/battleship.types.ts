export interface Ship {
  x: number;
  y: number;
  width: number;
  height: number;
  currentlyActive?: boolean;
  size?: number;
}

export interface CoordinatePoints {
  x: number;
  y: number;
}

export interface CanvasProps {
  width?: number;
  height?: number;
  id: string;
  isGrid?: boolean;
  className?: string;
  gridCellSize?: number;
  isPlayground?: boolean;
  startingPoint?: number;
  isCoordinates?: boolean;
  isShipyard?: boolean;
  isShips?: boolean;
  shipp?: boolean;
  setShips?: () => void;
  isHighlight?: boolean;
}
