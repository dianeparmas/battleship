import React, { useEffect, useRef, useState } from "react";

import {
  drawRectangle,
  getMouseCoordinates,
  drawStrike,
  // getMouseOffsetCoordinates,
} from "../../../utils/canvasUtils";

import mockOpponentBoard from "../../../assets/mockOpponentBoard.js";

import {
  CanvasProps,
  // CoordinatePoints,
  Ship,
} from "../../../types/battleship.types";

import styles from "./OpponentCanvas.module.css";

const OpponentCanvas = ({
  width = 500,
  height = 500,
  id,
  className = "",
  gridCellSize = 50,
  setShips,
}: CanvasProps) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const highlightCell = useRef<Ship>({
    x: 0,
    y: 0,
    width: 0,
    height: 0,
    currentlyActive: false,
  });

  useEffect(() => {
    console.log(mockOpponentBoard);
    const ctx = canvasRef?.current?.getContext("2d");
    if (ctx) {
      mockOpponentBoard.forEach((rect) => drawRectangle(ctx, rect));
    }
  }, []);

  const handleMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const ctx = canvasRef?.current?.getContext("2d");
    const { x, y } = getMouseCoordinates(event, canvasRef);
    if (ctx) {
      const activeColumn = Math.floor(x / gridCellSize) + 1;
      const activeRow = Math.floor(y / gridCellSize) + 1;
      // console.log('activeColumn:', Math.floor(x / 50) + 1, 'activeRow: ', Math.floor(y / 50) + 1);

      if (x > 0) {
        highlightCell.current = {
          y: activeRow * gridCellSize - gridCellSize,
          x: activeColumn * gridCellSize - gridCellSize,
          width: gridCellSize,
          height: gridCellSize,
        };
        drawRectangle(ctx, highlightCell.current, true, true, mockOpponentBoard);
        // console.log(highlightCell.current);
      }
    }
  };

  const checkStrike = () => {
    const ctx = canvasRef?.current?.getContext("2d");
    if (ctx && highlightCell.current) {
      console.log(mockOpponentBoard, highlightCell.current);
      let isHit = false;

      for (const ship of mockOpponentBoard) {
        console.log(ship, isHit);
        // isHit = ship.sections.some(
        //   (rect) =>
        //     rect.x === highlightCell.current.x &&
        //     rect.y === highlightCell.current.y,
        // );

        isHit = ship.sections.some((rect) => {
          if (
            rect.x === highlightCell.current.x &&
            rect.y === highlightCell.current.y
          ) {
            rect.hit = true;
            return true;
          }
        });

        if (isHit) {
          break;
        }
      }

      const image = new Image();
      image.onload = function () {
        drawStrike(ctx, { image, highlightCell, gridCellSize });
      };

      if (isHit) {
        console.log("Hit!");
        image.src = "fire.svg";
      } else {
        console.log("Miss!");
        image.src = "explosion.svg";
      }
    }
  };


  const handleMouseDown = (event: React.MouseEvent<HTMLCanvasElement>) => {
    console.log('mousedown');
    const ctx = canvasRef?.current?.getContext("2d");
    if (ctx && highlightCell.current) {
      console.log(highlightCell.current);
      checkStrike();
      // const image = new Image();
      // image.onload = function () {
      //   drawStrike(ctx, { image, highlightCell, gridCellSize });
      // };
      // image.src = "fire.svg";
    }
  };

  return (
    <>
      <canvas
        ref={canvasRef}
        id={id}
        width={width}
        height={height}
        className={styles[className]}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        // onMouseUp={handleMouseUp}
      />
      <p></p>
    </>
  );
};

export default OpponentCanvas;
