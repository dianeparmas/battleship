import React from "react";

export interface Ship {
  x: number;
  y: number;
  width: number;
  height: number;
  currentlyActive?: boolean;
  size?: number;
  isHorizontal?: boolean;
  sections: [{ x: number; y: number; hit: boolean }];
}

export interface CoordinatePoints {
  x: number;
  y: number;
}

export interface CanvasProps {
  width?: number;
  height?: number;
  id: string;
  isGrid?: boolean;
  className?: string;
  gridCellSize?: number;
  isPlayground?: boolean;
  startingPoint?: number;
  isCoordinates?: boolean;
  isShipyard?: boolean;
  isShips?: boolean;
  shipp?: boolean;
  setShips?: () => void;
  isHighlight?: boolean;
}

export interface ImgObj {
  image: HTMLImageElement;
  highlightCell: React.MutableRefObject<Ship>;
  gridCellSize: number;
}
